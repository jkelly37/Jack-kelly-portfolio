public interface AI {

    public Card getPlay(Hand hand, CardPile cardPile);

    public String toString();
}
