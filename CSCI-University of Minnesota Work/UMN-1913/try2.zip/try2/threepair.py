
list = [2,2,3,2]

def singlereturn(list):
    return list.max()


