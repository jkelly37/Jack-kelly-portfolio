public class Square extends Rectangle{

    public Square(int side1){
        super(side1,side1);
    }
}
