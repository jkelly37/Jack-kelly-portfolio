import java.math.*;

public class Rectangle extends Polygon {
    public Rectangle( int side1, int side2){
        super(4,side1,side2,side1,side2);

    }

    public int getArea(){
        return side(1) * side(2);

    }

    public double getDiagonal(){
        return(Math.sqrt(Math.pow(side(1),2) + Math.pow(side(2),2)));

    }
}
